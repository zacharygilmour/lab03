# week-3-starter
Starter code for week 3 lab exercise<br>
This lab is to be done in pairs <br>

You should find three files
<ol>
<li> duplicate.py </li>
<li> fibonacci.py </li>
<li> shuffle.py </li>
</ol>

Inside these files, you need to implement a function. <br>
The documentation for the functions are available within the respective file.<br>

<strong> Note </strong> that for this lab, you need to get yourself marked within the lab<br>
When you are done, push your changes to git, show your work to your tutor and get yourself 
marked off.
